@extends('layouts.web.foodsets', [
    'title' => 'Royal Emelina | Food Sets'
])

@section('content')
    <h1>Food Sets Page</h1>
@endsection