@extends('layouts.web.foodsets', [
    'title' => 'Royal Emelina | Show Food Set'
])

@section('content')
    <h1>Show Food Set</h1>
@endsection