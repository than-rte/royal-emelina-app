@extends('layouts.web.foodsets', [
    'title' => 'Royal Emelina | Food SubSet'
])

@section('content')
    <h1>Show Food Subset </h1>
@endsection