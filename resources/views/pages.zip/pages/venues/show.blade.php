@extends('layouts.web.venues', [
    'title' => 'Royal Emelina | Venue Show'
])

@section('content')
    <h1>This is Venues Show</h1>
@endsection