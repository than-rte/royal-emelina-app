@extends('layouts.web.venues', [
    'title' => 'Royal Emelina | Venues'
])

@section('content')
    <h1>This is Venues</h1>
@endsection