@extends('layouts.web.enquiry_search', [
    'title' => 'Royal Emelina | Search'
])

@section('content')
    <h1>Show Available Venues</h1>
@endsection