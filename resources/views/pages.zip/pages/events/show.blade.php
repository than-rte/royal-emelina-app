@extends('layouts.web.events', [
    'title' => 'Royal Emelina | Event Show'
])

@section('content')
    <h1>This is Event Show</h1>
@endsection