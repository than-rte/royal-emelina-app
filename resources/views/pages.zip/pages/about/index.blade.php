@extends('layouts.web.pages', [
    'title' => 'Royal Emelina | About'
])

@section('content')
    <h1>This is About Page</h1>
@endsection