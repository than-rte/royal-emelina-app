@extends('layouts.web.venues', [
    'title' => 'Royal Emelina | Contacts'
])

@section('content')
    <h1>This is Contacts</h1>
@endsection